import Best from "@/components/Best";
import Carousel from "@/components/Carousel";
import Footer from "@/components/Footer";
import Ibs from "@/components/Ibs";
import Imgwithtext from "@/components/Imgwithtext";
import Logo from "@/components/Logo";
import Navbar from "@/components/Navbar";
import Recently from "@/components/Recently";
import Review from "@/components/review";
import Slider from "@/components/Slider";
import Trending from "@/components/trending";

export default function Home() {
  return (
    <>
      <Logo />
      <Navbar />
      <Slider/>
      <Imgwithtext />
      <Trending />
      <Review/>
      <Best/>
      <Ibs/>
      <Recently/>
      <Footer/>
    </>
  );
}

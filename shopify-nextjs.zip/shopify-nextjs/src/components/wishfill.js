import Image from 'next/image'
import React from 'react'

const Wishfill = () => {
  return (
    <div>
        <Image src={'/heartfill.png'} width={41} height={38}></Image>
    </div>
  )
}

export default Wishfill
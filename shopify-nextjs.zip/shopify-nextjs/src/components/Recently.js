import Image from "next/image";
import React from "react";

const Recently = () => {
  const imgs = [
    "/p5.png",
    "/p6.png",
    "/p7.png",
    "/p8.png",
    "/p9.png",
    "/p10.png",
    "/p11.png",
  ].reverse();

  return (
    <section className="px-10 md:pt-20 pt-10 text-center">
      <h3 className=' md:text-[40px] text-2xl'>RECENTLY VIEWED</h3>
      <div className="flex items-center justify-between flex-wrap md:pb-44 py-8">
        {imgs.map((img, index) => (
          <Image
            className="pt-8"
            key={index}
            src={img}
            width={100}
            height={100}
            alt="Recently Viewed"
          />
        ))}
      </div>
      <Image src={"/GetMeThis.png"} width={1829} height={1186.36}></Image>
      <div className="md:py-20 pt-10">
        <h1 className=' md:text-[40px] text-2xl' >TALK TO HUMAN</h1>
        <div className="flex md:flex-row flex-col items-center justify-between flex-wrap py-8">
          <div className="flex items-center justify-center flex-col m-auto py-10">
            <svg
              fill="currentColor"
              viewBox="0 0 16 16"
              height="4rem"
              width="4rem"
            >
              <path d="M8 3a5 5 0 00-5 5v1h1a1 1 0 011 1v3a1 1 0 01-1 1H3a1 1 0 01-1-1V8a6 6 0 1112 0v5a1 1 0 01-1 1h-1a1 1 0 01-1-1v-3a1 1 0 011-1h1V8a5 5 0 00-5-5z" />
            </svg>
            <p className="pt-4">PHONE</p>
          </div>
          <div className="flex items-center justify-center flex-col m-0 py-10 md:w-1/3 w-full md:border-y-0 md:border-x border-y border-black">
            <svg
              viewBox="0 0 900 1000"
              fill="currentColor"
              height="4rem"
              width="4rem"
            >
              <path d="M30 264C8.667 252-.667 238.667 2 224c1.333-9.333 10-14 26-14h846c25.333 0 32 10.667 20 32-5.333 9.333-13.333 16.667-24 22-9.333 4-73.333 38-192 102s-179.333 96.667-182 98c-10.667 6.667-26 10-46 10-18.667 0-34-3.333-46-10-2.667-1.333-63.333-34-182-98S39.333 268 30 264m850 100c13.333-6.667 20-3.333 20 10v368c0 10.667-5.667 21.333-17 32-11.333 10.667-22.333 16-33 16H50c-10.667 0-21.667-5.333-33-16-11.333-10.667-17-21.333-17-32V374c0-13.333 6.667-16.667 20-10l384 200c12 6.667 27.333 10 46 10s34-3.333 46-10l384-200" />
            </svg>
            <p className="pt-4">EMAIL US</p>
          </div>
          <div className="flex items-center justify-center flex-col m-auto py-10">
            <svg
              fill="currentColor"
              viewBox="0 0 16 16"
              height="4rem"
              width="4rem"
            >
              <path d="M13.601 2.326A7.854 7.854 0 007.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 003.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0013.6 2.326zM7.994 14.521a6.573 6.573 0 01-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 01-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 014.66 1.931 6.557 6.557 0 011.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 00-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z" />
            </svg>
            <p className="pt-4">WHATSAPP US</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Recently;

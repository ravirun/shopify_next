"use client";
import Image from "next/image";
import React, { useState } from "react";
import Wishfill from "./wishfill";
import Wishoutline from "./wishoutline";

const Productcard = ({ image, name, price, imageWidth, imageHeight }) => {
  const [isWished, setIsWished] = useState(false);

  const handleWishClick = () => {
    setIsWished(!isWished);
  };

  return (
    <>
      <div className=" ">
        <div className="relative w-full">
          <Image
            src={image}

            width={imageWidth}
            height={imageHeight}
            // fill={true}
            className=''
            style={{objectFit: "contain"}}
          />
          <div className="absolute top-4 right-4 md:w-auto w-5">
            <button onClick={handleWishClick}>
              {isWished ? <Wishfill /> : <Wishoutline />}
            </button>
          </div>
        </div>
        <h3 className="py-4 font-semibold text-sm min-h-min">{name}</h3>
        <p className="text-[#727271]">
          <sup>₹</sup> {price}
        </p>
      </div>
      
    </>
  );
};

export default Productcard;

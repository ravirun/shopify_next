import Image from "next/image";
import React from "react";
import Logo from "./Logo";

const Navbar = () => {
  return (
    <>
      <div className="navbar bg-base-100 flex items-center justify-center px-8">
        <div class="md:pr-16 pr-4">
          <div class="dropdown">
            <label
              tabindex="0"
              class="btn btn-ghost btn-circle hover:bg-transparent"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="68"
                height="47"
                viewBox="0 0 68 47"
              >
                <g
                  id="Group_10"
                  data-name="Group 10"
                  transform="translate(-24 -381)"
                >
                  <g
                    id="Rectangle_26"
                    data-name="Rectangle 26"
                    transform="translate(24 381)"
                    stroke="#707070"
                    stroke-width="1"
                  >
                    <rect width="68" height="9" stroke="none" />
                    <rect x="0.5" y="0.5" width="67" height="8" fill="none" />
                  </g>
                  <g
                    id="Rectangle_27"
                    data-name="Rectangle 27"
                    transform="translate(24 400)"
                    stroke="#707070"
                    stroke-width="1"
                  >
                    <rect width="68" height="9" stroke="none" />
                    <rect x="0.5" y="0.5" width="67" height="8" fill="none" />
                  </g>
                  <g
                    id="Rectangle_28"
                    data-name="Rectangle 28"
                    transform="translate(24 419)"
                    stroke="#707070"
                    stroke-width="1"
                  >
                    <rect width="68" height="9" stroke="none" />
                    <rect x="0.5" y="0.5" width="67" height="8" fill="none" />
                  </g>
                </g>
              </svg>
            </label>
            <ul
              tabindex="0"
              class="menu menu-compact dropdown-content mt-3 p-2 shadow bg-base-100 rounded-box w-52"
            >
              <li>
                <a>Homepage</a>
              </li>
              <li>
                <a>Portfolio</a>
              </li>
              <li>
                <a>About</a>
              </li>
            </ul>
          </div>
        </div>
        <div className="form-control w-full">
          <div className="input-group">
            <input
              type="text"
              placeholder="Search…"
              className="input input-bordered w-full border-black border-r-0 focus:outline-none"
            />
            <button className="btn btn-square bg-white border-l-0 text-black hover:bg-gray-300">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </button>
          </div>
        </div>
        <div className="flex-none md:pl-16 pl-4">
          <div className="dropdown dropdown-end">
            <label tabIndex={0} className="btn btn-ghost btn-circle">
              <div className="indicator">
                <Image src={'/ShoppingBag.png'} alt='cart icon' width={65} height={65}></Image>
                {/* <span className="badge badge-sm indicator-item">8</span> */}
              </div>
            </label>
            <div
              tabIndex={0}
              className="mt-3 card card-compact dropdown-content w-52 bg-base-100 shadow"
            >
              <div className="card-body">
                <span className="font-bold text-lg">8 Items</span>
                <span className="text-info">Subtotal: $999</span>
                <div className="card-actions">
                  <button className="btn btn-primary btn-block">
                    View cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;

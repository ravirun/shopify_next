import Image from "next/image";
import Link from "next/link";
import React from "react";

const Imgwithtext = () => {
  return (
    <section className="container flex items-center md:flex-row flex-col justify-center w-full m-auto text-center md:py-20 py-4 bg-white px-10">
      <div className="md:w-1/2">
        <Image
          src={"/MaskGroup2.png"}
          alt="Mask Group 2"
          height={797}
          width={900}
        ></Image>
      </div>
      <div className="md:w-1/2 text-center m-auto md:p-10 p-4 pb-0">
        <p className=' md:text-3xl text-xl'>THE STYLE ESSENTIALS</p>
        <p className=' md:text-3xl text-lg'>
          Allow notifications for tailored new arrivals,
          exciting launches and promotions.
        </p>
        <button className="btn btn-ghost border-black border rounded-lg w-full hover:border-black my-4 font-bold capitalize">
          <Link className="" href={"/"}>Explore More</Link>
        </button>
      </div>
    </section>
  );
};

export default Imgwithtext;

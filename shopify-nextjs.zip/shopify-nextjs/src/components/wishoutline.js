import Image from 'next/image'
import React from 'react'

const Wishoutline = () => {
  return (
    <div>
        <Image src={'/heartout.png'} width={41} height={38}></Image>
    </div>
  )
}

export default Wishoutline
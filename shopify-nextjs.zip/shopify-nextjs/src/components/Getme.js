import React from 'react'

const Getme = () => {
  return (
    <div>
      Getme
    </div>
  )
}

export default Getme

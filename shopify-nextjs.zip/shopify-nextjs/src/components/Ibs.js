import React from 'react';
import Productcard from './Productcard';

const products = [
  {
    image: '/p1.png',
    name: 'Meta Quest 2 — Advanced All-In-One Virtual Reality Headset — 128 GB',
    price: '31,970.00',
    width: '359',
    height: '388'
  },
  {
    image: '/p1.png',
    name: 'Corsair Vengeance RGB PRO 16GB (2x8GB) DDR4 3200MHz C16 LED Desktop Memory - Black',
    price: '31,970.00',
    width: '359',
    height: '388'
  },
  {
    image: '/p1.png',
    name: 'Apple Watch Series 8 GPS + Cellular 45mm Midnight Aluminium Case with Midnight Sport Band - M/L',
    price: '31,970.00',
    width: '359',
    height: '388'
  },
  {
    image: '/p1.png',
    name: 'Meta Quest 2 — Advanced All-In-One Virtual Reality Headset — 128 GB',
    price: '31,970.00',
    width: '359',
    height: '388'
  },
];

const Ibs = () => {
  return (
    <section className='px-10 md:py-12 py-8'>
      <div className='flex items-center justify-between py-8'>
        <h3 className=' md:text-[40px] text-2xl'>INTERNATIONAL BEST SELLERS</h3>
        <button className='btn btn-ghost border-black border rounded-lg hover:border-black my-4 font-bold capitalize'>
          View all
        </button>
      </div>
      <div className='gap-6 md:gap-8  grid md:grid-cols-4 grid-cols-2'>
        {products && products.map((product, index) => (
          <Productcard
            key={index}
            image={product.image}
            name={product.name}
            price={product.price}
            imageWidth={product.width}
            imageHeight={product.height}
          />
        ))}
      </div>
    </section>
  );
};

export default Ibs;

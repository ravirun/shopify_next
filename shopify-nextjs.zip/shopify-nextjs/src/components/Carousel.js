"use client"
import React, { useState } from "react";
import Image from "next/image";

const Carousel = () => {
  const reviews = [
    {
      review:
        "Wyze Cam v3 with Color Night Vision, Wired 1080p HD Indoor/Outdoor Video Camera",
      img: "/avatar.png",
      name: "Ritu Kaur",
    },
    {
      review:
        "Wyze Cam v3 with Color Night Vision, Wired 1080p HD Indoor/Outdoor Video Camera",
      img: "/avatar.png",
      name: "Ritu Kaur",
    },
    {
      review:
        "Wyze Cam v3 with Color Night Vision, Wired 1080p HD Indoor/Outdoor Video Camera",
      img: "/avatar.png",
      name: "Ritu Kaur",
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  const handlePrev = () => {
    const newIndex = activeIndex === 0 ? reviews.length - 1 : activeIndex - 1;
    setActiveIndex(newIndex);
    updateActiveDot(newIndex);
  };

  const handleNext = () => {
    const newIndex = activeIndex === reviews.length - 1 ? 0 : activeIndex + 1;
    setActiveIndex(newIndex);
    updateActiveDot(newIndex);
  };

  const updateActiveDot = (index) => {
    const dots = document.getElementsByClassName("dot");
    for (let i = 0; i < dots.length; i++) {
      dots[i].classList.remove("active");
    }
    dots[index].classList.add("active");
  };



  const handleDotClick = (index) => {
    setActiveIndex(index);
    updateActiveDot(index);
  };

  return (
    <section className="bg-white px-10 md:py-20 py-10 pb-0">
      <div className="border-y border-black py-10 text-center">
        <p className=' md:text-[40px] text-2xl'>CUSTOMER REVIEWS</p>
        <div className="flex items-center justify-center m-auto py-8">
          <Image src={"/45.png"} width={229} height={138} alt="rating" />
        </div>
        <div className="md:text-4xl text-lg md:px-28">{reviews[activeIndex].review}</div>
        <div className="flex items-center justify-center md:w-1/4 m-auto p-4">
          <Image
            src={reviews[activeIndex].img}
            width={50}
            height={50}
            alt={reviews[activeIndex].name}
          />
          <p className="pl-4">{reviews[activeIndex].name}</p>
        </div>
        <div className="m-auto flex items-center justify-center">
          {reviews.map((review, index) => (
            <div
              key={index}
              className={`dot w-3 h-3 opacity-50 bg-black rounded-full m-1 hover:opacity-100 ${index === activeIndex ? "active opacity-100" : ""}`}
              onClick={() => handleDotClick(index)}
            ></div>
          ))}
        </div>
        {/* <div className="flex justify-center mt-4">
          <button
            className="text-xl md:text-5xl cursor-pointer"
            onClick={handlePrev}
          >
            {"<"}
          </button>
          <button
            className="text-xl md:text-5xl cursor-pointer"
            onClick={handleNext}
          >
            {">"}
          </button>
        </div> */}
      </div>
    </section>
  );
};

export default
 Carousel;

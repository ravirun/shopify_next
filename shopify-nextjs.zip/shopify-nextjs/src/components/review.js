import React from 'react'
import Carousel from './Carousel'

const Review = () => {
  return (
    <div>
        <Carousel/>
    </div>
  )
}

export default Review
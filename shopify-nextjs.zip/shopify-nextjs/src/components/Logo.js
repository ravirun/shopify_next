import Image from 'next/image'
import React from 'react'

const Logo = () => {
  return (
    <div className='grid place-content-center bg-white py-10 md:px-0 px-8'>
      <Image src={'/logo.png'} alt='theglobalgenie Logo in black' width={843} height={155}>
    </Image>
    </div>
  )
}

export default Logo
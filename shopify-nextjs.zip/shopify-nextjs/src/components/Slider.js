"use client";

import Image from "next/image";
import React, { useState } from "react";

const Slider = () => {
  const reviews = [
    {
      img: "/hero1.png",
    },
    {
      img: "/hero1.png",
    },
    {
      img: "/hero1.png",
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  const updateActiveDot = (index) => {
    const dots = document.getElementsByClassName("dot");
    for (let i = 0; i < dots.length; i++) {
      dots[i].classList.remove("active");
    }
    dots[index].classList.add("active");
  };

  const handleDotClick = (index) => {
    setActiveIndex(index);
    updateActiveDot(index);
  };

  return (
    <section className="bg-white">
      <div className="flex relative items-center justify-center m-auto py-8">
        <Image
          src={reviews[activeIndex].img}
          className="w-screen"
          width={229}
          height={138}
          alt="rating"
        />
        <div className="m-auto absolute top-[80%] flex items-center justify-center">
        {reviews.map((review, index) => (
          <div
            key={index}
            className={`dot w-10 h-1 rounded-full m-1 hover:bg-white ${
              index === activeIndex ? "active opacity-100 bg-white" : "bg-black"
            }`}
            onClick={() => handleDotClick(index)}
          ></div>
        ))}
      </div>
      </div>
      
    </section>
  );
};

export default Slider;
